package elearning.converter;

import elearning.dto.UserDto;
import elearning.entity.UserEntity;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class UserConverter implements BaseMapper<UserEntity, UserDto> {

    private final ModelMapper modelMapper;

    @Override
    public UserEntity toEntity(UserDto dto) {
        return modelMapper.map(dto, UserEntity.class);
    }

    @Override
    public UserDto toDTO(UserEntity entity) {
        return modelMapper.map(entity, UserDto.class);
    }
}
