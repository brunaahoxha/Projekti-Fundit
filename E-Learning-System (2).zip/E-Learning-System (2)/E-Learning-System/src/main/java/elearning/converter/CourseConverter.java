package elearning.converter;

import elearning.dto.CourseDto;
import elearning.dto.SubjectDto;
import elearning.entity.CourseEntity;
import elearning.entity.SubjectEntity;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class CourseConverter implements BaseMapper<CourseEntity, CourseDto> {

    private final ModelMapper modelMapper;


    @Override
    public CourseEntity toEntity(CourseDto dto) {
        return modelMapper.map(dto, CourseEntity.class);
    }

    @Override
    public CourseDto toDTO(CourseEntity entity) {
        return modelMapper.map(entity, CourseDto.class);
    }
}
