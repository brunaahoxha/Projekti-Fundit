package elearning.converter;

import elearning.dto.SubjectDto;
import elearning.entity.SubjectEntity;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SubjectConverter implements BaseMapper<SubjectEntity, SubjectDto> {

    private final ModelMapper modelMapper;

    @Override
    public SubjectEntity toEntity(SubjectDto dto) {
        return modelMapper.map(dto, SubjectEntity.class);
    }

    @Override
    public SubjectDto toDTO(SubjectEntity entity) {
        return modelMapper.map(entity, SubjectDto.class);
    }
}
