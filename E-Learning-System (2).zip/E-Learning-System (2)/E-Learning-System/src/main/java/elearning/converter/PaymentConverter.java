package elearning.converter;

import elearning.dto.PageDto;
import elearning.dto.PaymentDto;
import elearning.entity.PaymentEntity;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class PaymentConverter implements BaseMapper <PaymentEntity, PaymentDto>{

    private final ModelMapper modelMapper;

    @Override
    public PaymentEntity toEntity(PaymentDto dto) {
        return modelMapper.map(dto, PaymentEntity.class);
    }

    @Override
    public PaymentDto toDTO(PaymentEntity entity) {
        return modelMapper.map(entity, PaymentDto.class);
    }
}
