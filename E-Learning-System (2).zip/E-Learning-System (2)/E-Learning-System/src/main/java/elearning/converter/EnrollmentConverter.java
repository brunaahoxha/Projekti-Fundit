package elearning.converter;

import elearning.dto.EnrollmentDto;
import elearning.entity.EnrollmentEntity;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class EnrollmentConverter implements BaseMapper<EnrollmentEntity, EnrollmentDto> {

    private final ModelMapper modelMapper;

    @Override
    public EnrollmentEntity toEntity(EnrollmentDto dto) {
        return modelMapper.map(dto, EnrollmentEntity.class);
    }

    @Override
    public EnrollmentDto toDTO(EnrollmentEntity entity) {
        return modelMapper.map(entity, EnrollmentDto.class);
    }
}
