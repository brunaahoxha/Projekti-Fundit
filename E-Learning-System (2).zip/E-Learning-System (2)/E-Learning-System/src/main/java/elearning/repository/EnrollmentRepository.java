package elearning.repository;

import elearning.entity.EnrollmentEntity;
import elearning.entity.SubjectEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EnrollmentRepository extends JpaRepository<EnrollmentEntity, Long> {
}
