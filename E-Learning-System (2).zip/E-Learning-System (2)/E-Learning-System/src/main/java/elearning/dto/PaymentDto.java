package elearning.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PaymentDto {
    private Long id;
    private Integer amount;
    private UserDto student;
}
