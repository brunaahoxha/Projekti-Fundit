package elearning.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SubjectDto {
    private Long id;
    private String name;
    private UserDto user;
}
