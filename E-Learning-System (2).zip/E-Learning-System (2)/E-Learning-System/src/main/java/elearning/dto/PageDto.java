package elearning.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import java.util.List;

@Data
@Builder
public class PageDto {
    private Long totalElements;
    private Integer totalPages;
    private Integer size;
    private Boolean first;
    private Boolean last;

}
