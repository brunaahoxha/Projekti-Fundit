package elearning.entity;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import java.time.LocalDateTime;


@Getter
@Setter
public class BaseEntity {

    @CreatedDate
    @Column(name = "created_on")
    private LocalDateTime createdOn;

    @LastModifiedDate
    @Column(name = "updated_on")
    private LocalDateTime updatedOn;

    @Column(name = "deleted_on")
    private LocalDateTime deletedOn;

    @PrePersist
    public final void onInsert() {
        LocalDateTime now = LocalDateTime.now();
        if (this.createdOn == null) {
            this.createdOn = now;
        }

        this.updatedOn = now;
    }

    @PreUpdate
    public final void onUpdate() {
        this.updatedOn = LocalDateTime.now();
    }
}