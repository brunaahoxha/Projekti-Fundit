package elearning.controller;
import elearning.dto.EnrollmentDto;
import elearning.entity.EnrollmentEntity;
import elearning.service.EnrollmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/enrollment")
@RequiredArgsConstructor
public class EnrollmentController {

    private final EnrollmentService enrollmentService;

    @GetMapping("/")
    public List<EnrollmentDto> getAllEnrollments() {
        return enrollmentService.getAll();
    }

    @GetMapping("/{id}")
    public EnrollmentDto getEnrollmentById(@PathVariable Long id) {
        return enrollmentService.getById(id);
    }

    @PostMapping("/")
    public EnrollmentDto createEnrollment(@RequestBody EnrollmentDto enrollmentDto) {
        return enrollmentService.createEnrollment(enrollmentDto);
    }

    @DeleteMapping("/{id}")
    public void deleteEnrollment(@RequestBody EnrollmentDto enrollmentDto) {
        enrollmentService.delete(enrollmentDto);
    }

    @PutMapping("/{id}")
    public EnrollmentDto updateEnrollment(@PathVariable Long id, @RequestBody EnrollmentDto enrollment) {
        enrollment.setId(id);
        return enrollmentService.update(enrollment);
    }
}