package elearning.controller;

import elearning.dto.PaymentDto;
import elearning.entity.PaymentEntity;
import elearning.service.PaymentService;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/payment")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    @GetMapping
    public List<PaymentDto> getAllPayments() {
        return paymentService.getAll();
    }

    @GetMapping("/{id}")
    public PaymentDto getPaymentById(@PathVariable Long id) {
        return paymentService.getById(id);
    }

    @PostMapping
    public PaymentDto createPayment(@RequestBody PaymentDto paymentDto) {
        return paymentService.createPayment(paymentDto);
    }

    @DeleteMapping
    public void deletePayment(@RequestBody PaymentDto paymentDto) {
        paymentService.delete(paymentDto);
    }

    @PutMapping
    public PaymentDto updatePayment(@RequestBody PaymentDto paymentDto) {
        return paymentService.update(paymentDto);
    }
}

