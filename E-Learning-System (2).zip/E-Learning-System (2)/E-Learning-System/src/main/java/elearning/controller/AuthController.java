package elearning.controller;


import elearning.dto.UserDto;
import elearning.service.UserService;
import elearning.service.impl.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    TokenService tokenService;


    @Autowired
    UserService userService;

    @PostMapping("/token")
    public String generateToken(Authentication auth){
        var token = tokenService.generateToken(auth);
        return "Bearer ".concat(token);
    }

    @PostMapping("/register")
    public ResponseEntity<Void> registerUser(@RequestBody UserDto req){
        userService.createUser(req);
        return ResponseEntity.ok().build();
    }
}