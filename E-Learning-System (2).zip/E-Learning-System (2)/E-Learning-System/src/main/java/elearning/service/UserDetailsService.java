package elearning.service;

public interface UserDetailsService {
}
