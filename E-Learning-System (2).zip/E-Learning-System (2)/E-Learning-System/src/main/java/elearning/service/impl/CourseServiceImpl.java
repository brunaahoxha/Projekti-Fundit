package elearning.service.impl;

import elearning.converter.CourseConverter;
import elearning.converter.SubjectConverter;
import elearning.converter.UserConverter;
import elearning.dto.CourseDto;
import elearning.entity.CourseEntity;
import elearning.entity.SubjectEntity;
import elearning.repository.CourseRepository;
import elearning.service.CourseService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@RequiredArgsConstructor
public class CourseServiceImpl implements CourseService {

    private final CourseRepository courseRepository;
    private final CourseConverter courseConverter;
    private final SubjectConverter subjectConverter;


    @Override
    public CourseDto createCourse(CourseDto courseDto) {
        CourseEntity course = courseConverter.toEntity(courseDto);
        return courseConverter.toDTO(courseRepository.save(course));
    }

    @Override
    public List<CourseDto> getAll() {
        return courseRepository.findAll().stream()
                .map(courseConverter::toDTO).toList();
    }


    @Override
    public void delete(CourseDto courseDto) {
        courseRepository.delete(courseConverter.toEntity(courseDto));
    }

    @Override
    public CourseDto update(CourseDto courseDto) {
        CourseEntity dbCourse = courseRepository.findById(courseDto.getId()).orElseThrow();
        dbCourse.setName(courseDto.getName());
        dbCourse.setDescription(courseDto.getDescription());
        dbCourse.setContent(courseDto.getContent());
        dbCourse.setSubject(subjectConverter.toEntity(courseDto.getSubject()));
        return courseConverter.toDTO(courseRepository.save(dbCourse));
    }

    @Override
    public CourseDto getById(Long id) {
        return courseConverter.toDTO(courseRepository.findById(id).orElseThrow());
    }
}