package elearning.service.impl;

import elearning.converter.SubjectConverter;
import elearning.converter.UserConverter;
import elearning.dto.SubjectDto;
import elearning.entity.SubjectEntity;
import elearning.service.SubjectService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import elearning.repository.*;

import java.util.List;

@RequiredArgsConstructor
@Service
public class SubjectServiceImpl implements SubjectService {

    private final SubjectRepository subjectRepository;
    private final SubjectConverter subjectConverter;
    private final UserConverter userConverter;

    @Override
    public SubjectDto createSubject(SubjectDto subjectDto) {
        SubjectEntity subject = subjectConverter.toEntity(subjectDto);
        return subjectConverter.toDTO(subjectRepository.save(subject));
    }

    @Override
    public List<SubjectDto> getAll() {
        return subjectRepository.findAll().stream()
                .map(subjectConverter::toDTO).toList();
    }

    @Override
    public void delete(SubjectDto subjectDto) {
        subjectRepository.delete(subjectConverter.toEntity(subjectDto));
    }


    @Override
    public SubjectDto update(SubjectDto subjectDto) {

        SubjectEntity dbSubject = subjectRepository.findById(subjectDto.getId()).orElseThrow();
        dbSubject.setName(subjectDto.getName());
        dbSubject.setUser(userConverter.toEntity(subjectDto.getUser()));

        return subjectConverter.toDTO(subjectRepository.save(dbSubject));
    }

    @Override
    public SubjectDto getById(Long id) {

        return subjectConverter.toDTO(subjectRepository.findById(id).orElseThrow());
    }
}
