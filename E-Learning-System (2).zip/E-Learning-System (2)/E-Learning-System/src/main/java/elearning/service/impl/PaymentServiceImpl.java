package elearning.service.impl;

import elearning.converter.PaymentConverter;
import elearning.converter.UserConverter;
import elearning.dto.PaymentDto;
import elearning.entity.PaymentEntity;
import elearning.repository.PaymentRepository;
import elearning.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;
    private final PaymentConverter paymentConverter;
    private final UserConverter userConverter;

    @Override
    public PaymentDto createPayment(PaymentDto paymentDto) {
        PaymentEntity entity = paymentRepository.save(paymentConverter.toEntity(paymentDto));
        return paymentConverter.toDTO(entity);
    }

    @Override
    public List<PaymentDto> getAll() {
        return paymentRepository.findAll()
                .stream()
                .map(paymentConverter::toDTO)
                .toList();
    }

    @Override
    public void delete(PaymentDto paymentDto) {
        PaymentEntity payment = paymentRepository.getById(paymentDto.getId());
        paymentRepository.delete(payment);
    }

    @Override
    public PaymentDto update(PaymentDto paymentDto) {

        PaymentEntity dbPayment = paymentRepository.findById(paymentDto.getId()).orElseThrow();
        dbPayment.setAmount(paymentDto.getAmount());
        dbPayment.setStudent(userConverter.toEntity(paymentDto.getStudent()));

        return paymentConverter.toDTO(paymentRepository.save(dbPayment));
    }

    @Override
    public PaymentDto getById(Long id) {
        return paymentConverter.toDTO(paymentRepository.findById(id).orElseThrow());
    }
}
