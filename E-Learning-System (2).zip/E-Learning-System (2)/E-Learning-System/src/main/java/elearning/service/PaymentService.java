package elearning.service;

import elearning.dto.PaymentDto;
import elearning.entity.PaymentEntity;

import java.util.List;

public interface PaymentService {
    PaymentDto createPayment(PaymentDto paymentDto);
    List<PaymentDto> getAll();
    void delete(PaymentDto paymentDto);

    PaymentDto update(PaymentDto payment);
    PaymentDto getById(Long id);
}