package elearning.service;

import elearning.dto.SubjectDto;

import java.util.List;

public interface SubjectService {
    SubjectDto createSubject(SubjectDto subjectDto);
    List<SubjectDto> getAll();
    void delete(SubjectDto subjectDto);
    SubjectDto update(SubjectDto subjectDto);
    SubjectDto getById(Long id);
}
