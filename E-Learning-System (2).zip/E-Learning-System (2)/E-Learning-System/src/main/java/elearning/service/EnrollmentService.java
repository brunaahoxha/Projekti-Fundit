package elearning.service;

import elearning.dto.EnrollmentDto;

import java.util.List;

public interface EnrollmentService {
    EnrollmentDto createEnrollment(EnrollmentDto enrollmentDto);

    List<EnrollmentDto> getAll();

    void delete(EnrollmentDto enrollment);

    EnrollmentDto update(EnrollmentDto enrollment);

    EnrollmentDto getById(Long id);
}
