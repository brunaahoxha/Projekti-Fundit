package elearning.service;

import elearning.dto.CourseDto;
import elearning.entity.CourseEntity;

import java.util.List;

public interface CourseService {

    CourseDto createCourse(CourseDto courseDto);

    List<CourseDto> getAll();

    void delete(CourseDto courseDto);

    CourseDto update(CourseDto courseDto);

    CourseDto getById(Long id);
}
