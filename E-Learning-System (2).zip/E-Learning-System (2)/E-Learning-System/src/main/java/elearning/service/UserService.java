package elearning.service;

import elearning.dto.UserDto;
import elearning.entity.UserEntity;

import java.util.List;

public interface UserService {
    UserDto createUser(UserDto userDto);
    List<UserDto> getAll();
    void delete(UserDto user);
    UserDto update(UserDto user);
    UserDto getById(Long id);
}
