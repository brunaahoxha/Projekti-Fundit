package elearning.service.impl;

import elearning.converter.EnrollmentConverter;
import elearning.converter.UserConverter;
import elearning.dto.EnrollmentDto;
import elearning.entity.EnrollmentEntity;
import elearning.repository.EnrollmentRepository;
import elearning.service.EnrollmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EnrollmentServiceImpl implements EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;
    private final EnrollmentConverter enrollmentConverter;
    private final UserConverter userConverter;

    @Override
    public EnrollmentDto createEnrollment(EnrollmentDto enrollmentDto) {
        return enrollmentConverter.toDTO(
                enrollmentRepository.save(
                        enrollmentConverter.toEntity(enrollmentDto)
                )
        );
    }

    @Override
    public List<EnrollmentDto> getAll() {
        return enrollmentRepository.findAll().stream()
                .map(enrollmentConverter::toDTO)
                .toList();
    }

    @Override
    public void delete(EnrollmentDto enrollment) {
        enrollmentRepository.delete(enrollmentConverter.toEntity(enrollment));

    }

    @Override
    public EnrollmentDto update(EnrollmentDto enrollment) {

        EnrollmentEntity dbEnrollment = enrollmentRepository.findById(enrollment.getId()).orElseThrow();
        dbEnrollment.setStudent(userConverter.toEntity(enrollment.getStudent()));

        return enrollmentConverter.toDTO(enrollmentRepository.save(dbEnrollment));
    }

    @Override
    public EnrollmentDto getById(Long id) {
        return enrollmentConverter.toDTO(enrollmentRepository.findById(id).orElseThrow());
    }
}

