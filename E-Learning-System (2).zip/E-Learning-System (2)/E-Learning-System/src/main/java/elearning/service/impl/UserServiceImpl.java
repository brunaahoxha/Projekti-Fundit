package elearning.service.impl;

import elearning.converter.UserConverter;
import elearning.dto.UserDto;
import elearning.entity.UserEntity;
import elearning.exception.EntityNotFoundException;
import elearning.repository.UserRepository;
import elearning.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final UserConverter userConverter;

    @Override
    public UserDto createUser(UserDto userDto) {

        UserEntity user = userConverter.toEntity(userDto);
        user.setEnabled(true);

        return userConverter.toDTO(userRepository.save(user));
    }

    @Override
    public List<UserDto> getAll() {
        return userRepository.findAll()
                .stream()
                .map(userConverter::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public void delete(UserDto user) {
        userRepository.delete(userRepository.findById(user.getId()).orElseThrow());
    }

    @Override
    public UserDto update(UserDto user) {

        UserEntity dbUser = userRepository.findById(user.getId()).orElseThrow(() -> new EntityNotFoundException("User with id: " + user.getId() + "not found"));
        dbUser.setUsername(user.getUsername());
        dbUser.setFirstName(user.getFirstName());
        dbUser.setLastName(user.getLastName());
        dbUser.setPassword(user.getPassword());

        return userConverter.toDTO(userRepository.save(dbUser));
    }

    @Override
    public UserDto getById(Long id) {
        return userConverter.toDTO(userRepository.findById(id).orElseThrow(
                () -> new EntityNotFoundException("User with id: " + id + "not found"))
        );
    }
}
