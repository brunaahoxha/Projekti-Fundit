package elearning.enums;

public enum Role {
    TEACHER,
    ADMIN,
    STUDENT
}
